#!/bin/bash
palavra1="$1"
palavra2="$2"

if echo "$palavra2" | grep -q "$palavra1"; then
 echo  "$palavra1 está contida em $palavra2"
fi
