#!/bin/bash
juntatudo=$(echo "$*" | tr -d ' ')
echo "$juntatudo"

