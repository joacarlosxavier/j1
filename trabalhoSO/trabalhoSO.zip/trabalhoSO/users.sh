#!/bin/bash
cut -d ':' -f 1,5 /etc/passwd |
while IFS=: read -r usuario nome_completo; do
    echo -e "$usuario\t$nome_completo"
done
