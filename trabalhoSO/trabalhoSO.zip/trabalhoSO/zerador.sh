#!/bin/bash
x=$1
while [[ $x -ge 0 ]]; do
 echo -n "$x "
x=$(( x - 1 ))
done
echo
